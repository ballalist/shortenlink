<div class="logo-text text-center">
    <a href="{{ URL::to('/') }}">
        <h3>Short URL&trade;</h3>
    </a>
</div>