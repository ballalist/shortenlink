<div class="mt-10">
    @livewire('logo')
    <div class="my-10">
        <button wire:click="goToSecondStep" class="w-full rounded-full bg-orange-600 p-5 hover:bg-orange-800">GET Started for Free!</button>
    </div>
</div>