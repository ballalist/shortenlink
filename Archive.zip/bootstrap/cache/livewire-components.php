<?php return array (
  'admin-login' => 'App\\Http\\Livewire\\AdminLogin',
  'admin-management' => 'App\\Http\\Livewire\\AdminManagement',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'firststep' => 'App\\Http\\Livewire\\Firststep',
  'logo' => 'App\\Http\\Livewire\\Logo',
  'nolink' => 'App\\Http\\Livewire\\Nolink',
  'registerstep' => 'App\\Http\\Livewire\\Registerstep',
  'secondstep' => 'App\\Http\\Livewire\\Secondstep',
  'shortform' => 'App\\Http\\Livewire\\Shortform',
  'steps' => 'App\\Http\\Livewire\\Steps',
);