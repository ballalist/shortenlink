<?php $__env->startSection('content'); ?>
    <div class="relative flex h-full w-full">
        <div class="h-screen w-full">
            <div class="mx-auto flex h-full w-1/3 flex-col justify-center text-white xl:w-1/3">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-login')->html();
} elseif ($_instance->childHasBeenRendered('6Y1XzpR')) {
    $componentId = $_instance->getRenderedChildComponentId('6Y1XzpR');
    $componentTag = $_instance->getRenderedChildComponentTagName('6Y1XzpR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6Y1XzpR');
} else {
    $response = \Livewire\Livewire::mount('admin-login');
    $html = $response->html();
    $_instance->logRenderedChild('6Y1XzpR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/admin.blade.php ENDPATH**/ ?>