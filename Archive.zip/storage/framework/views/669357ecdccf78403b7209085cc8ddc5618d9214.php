<?php $__env->startSection('content'); ?>
    <?php if(!$notFound): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('steps')->html();
} elseif ($_instance->childHasBeenRendered('kom3GbZ')) {
    $componentId = $_instance->getRenderedChildComponentId('kom3GbZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('kom3GbZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kom3GbZ');
} else {
    $response = \Livewire\Livewire::mount('steps');
    $html = $response->html();
    $_instance->logRenderedChild('kom3GbZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php else: ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('nolink')->html();
} elseif ($_instance->childHasBeenRendered('f5GfZ7Q')) {
    $componentId = $_instance->getRenderedChildComponentId('f5GfZ7Q');
    $componentTag = $_instance->getRenderedChildComponentTagName('f5GfZ7Q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('f5GfZ7Q');
} else {
    $response = \Livewire\Livewire::mount('nolink');
    $html = $response->html();
    $_instance->logRenderedChild('f5GfZ7Q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/welcome.blade.php ENDPATH**/ ?>