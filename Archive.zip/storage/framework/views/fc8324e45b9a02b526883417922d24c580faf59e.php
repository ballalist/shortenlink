<div class="mt-10">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('logo')->html();
} elseif ($_instance->childHasBeenRendered('l3807095276-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3807095276-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3807095276-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3807095276-0');
} else {
    $response = \Livewire\Livewire::mount('logo');
    $html = $response->html();
    $_instance->logRenderedChild('l3807095276-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="my-10">
        <button wire:click="goToSecondStep" class="w-full rounded-full bg-orange-600 p-5 hover:bg-orange-800">GET Started for Free!</button>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/livewire/firststep.blade.php ENDPATH**/ ?>