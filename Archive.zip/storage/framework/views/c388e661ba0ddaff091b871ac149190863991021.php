<?php $__env->startSection('content'); ?>
    
    
    <div class="relative flex h-full w-full">
        <div class="h-screen w-full">
            <div class="mx-auto flex h-full w-1/3 flex-col justify-center text-white xl:w-1/3">
                <?php if(!$loggedIn): ?>
                
                <div>
                    <div class="mt-10">
                        <form wire:submit.prevent="login">
                            <div>
                                <label class="mb-2.5 block font-extrabold" for="email">Admin Email</label>
                                <input wire:model="email" type="email" id="email" class="inline-block w-full rounded-full bg-white p-2.5 leading-none text-black placeholder-indigo-900 shadow placeholder:opacity-30" placeholder="mail@user.com" />
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mt-4">
                                <label class="mb-2.5 block font-extrabold" for="password">Admin Password</label>
                                <input wire:model="password" type="password" id="password" class="inline-block w-full rounded-full bg-white p-2.5 leading-none text-black placeholder-indigo-900 shadow" />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-red-400"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="my-10">
                                <button class="w-full rounded-full bg-orange-600 p-5 hover:bg-orange-800">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <?php else: ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/livewire/admin.blade.php ENDPATH**/ ?>