<?php $__env->startSection('content'); ?>
    <div class="relative flex h-full w-full">
        <div class="h-screen w-full">
            <div class="mx-auto flex h-full w-2/3 flex-col justify-center text-white xl:w-2/3">
                <div class="overflow-x-auto relative">
                    <p class="text-right mb-10">
                        <a href="<?php echo e(URL::to('/admin')); ?>"><u>Logout</u></a>
                    </p>
                    
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="py-3 px-6">
                                    id
                                </th>
                                <th scope="col" class="py-3 px-6">
                                    Short URL
                                </th>
                                <th scope="col" class="py-3 px-6">
                                    Full URL
                                </th>
                                <th scope="col" class="py-3 px-6">
                                    Visited Stats
                                </th>
                                <th scope="col" class="py-3 px-6">
                                    Email
                                </th>
                                <th scope="col" class="py-3 px-6">
                                    Delete
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                <td scope="row" class="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    <?php echo e($link->id); ?>

                                </td>
                                <th scope="row" class="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($link->slug); ?>" target="_blank"><?php echo e(URL::to('/')); ?>/<?php echo e($link->slug); ?></a>
                                </th>
                                <th class="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    <a href="<?php echo e($link->url); ?>" target="_blank"><?php echo e($link->url); ?></a>
                                </th>
                                <td class="py-4 px-6 text-center">
                                    <?php echo e($link->stats); ?>

                                </td>
                                <td class="py-4 px-6">
                                    <?php echo e($link->user->email); ?>

                                </td>
                                <td class="py-4 px-6">
                                    <form action="<?php echo e(url('/admin-management/link/delete', ['id' => $link->id])); ?>" method="post">
                                        <button onclick="return confirm('Are you sure to archive this link?')" class="text-white bg-gradient-to-r from-red-400 via-red-500 to-red-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2">Archive</button>
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-10">
                    <?php echo e($links->links('pagination::tailwind')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/admin-management.blade.php ENDPATH**/ ?>