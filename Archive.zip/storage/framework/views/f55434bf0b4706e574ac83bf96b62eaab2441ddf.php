<div>
    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($link->url); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($links->links()); ?>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/livewire/admin-management.blade.php ENDPATH**/ ?>