<div class="logo-text text-center">
    <a href="<?php echo e(URL::to('/')); ?>">
        <h3>Short URL&trade;</h3>
    </a>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/livewire/logo.blade.php ENDPATH**/ ?>