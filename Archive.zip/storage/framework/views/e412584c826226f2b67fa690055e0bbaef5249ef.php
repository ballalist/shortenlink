<div class="relative flex h-full w-full">
  <div class="h-screen w-full">
    <div class="mx-auto flex h-full w-1/3 flex-col justify-center text-white xl:w-1/3">
        <?php if($step == 1): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('firststep')->html();
} elseif ($_instance->childHasBeenRendered('l1552385221-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1552385221-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1552385221-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1552385221-0');
} else {
    $response = \Livewire\Livewire::mount('firststep');
    $html = $response->html();
    $_instance->logRenderedChild('l1552385221-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php elseif($step == 2): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('secondstep')->html();
} elseif ($_instance->childHasBeenRendered('l1552385221-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1552385221-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1552385221-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1552385221-1');
} else {
    $response = \Livewire\Livewire::mount('secondstep');
    $html = $response->html();
    $_instance->logRenderedChild('l1552385221-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php elseif($step == 3): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('shortform')->html();
} elseif ($_instance->childHasBeenRendered('l1552385221-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l1552385221-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1552385221-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1552385221-2');
} else {
    $response = \Livewire\Livewire::mount('shortform');
    $html = $response->html();
    $_instance->logRenderedChild('l1552385221-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php elseif($step == 11): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('registerstep')->html();
} elseif ($_instance->childHasBeenRendered('l1552385221-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l1552385221-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1552385221-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1552385221-3');
} else {
    $response = \Livewire\Livewire::mount('registerstep');
    $html = $response->html();
    $_instance->logRenderedChild('l1552385221-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function copyText() {
        /* Get the text field */
        var copyText = document.getElementById("shortUrl");

        /* Select the text field */
        copyText.select();
        copyText.setSelectionRange(0, 99999); /* For mobile devices */

        /* Copy the text inside the text field */
        navigator.clipboard.writeText(copyText.value);
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/shorturl/resources/views/livewire/steps.blade.php ENDPATH**/ ?>